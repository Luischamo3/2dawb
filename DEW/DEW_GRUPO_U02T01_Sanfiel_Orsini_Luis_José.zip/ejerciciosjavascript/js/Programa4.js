/*Se deben añadir 5 imágenes a la página web para que
 al hacer click sobre ellas se muestre un
 mensaje como el siguiente: “Haz hecho click
 sobre la imagen número 1”, “Haz hecho
click sobre la imagen número 2”, etc */

function imgnumber(nimg) {
  var nimg;
  alert("Has hecho click en la imagen: " + nimg);
}
