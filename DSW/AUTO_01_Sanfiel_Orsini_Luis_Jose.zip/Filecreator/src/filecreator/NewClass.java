/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filecreator;

import java.util.Scanner;
/**
 *
 * @author Luis
 */
public class NewClass {
    public static void main(String[]args){
    //CARPETA TEMP
    
    String tmpF= System.getenv("TEMP");
    //NOMBRE DEL ARCHIVO
    String fileName = "\\practica.html";
    
    /// Preguntar por valores
    
    String titulo = addString("Título de la pagina: ");
    String nombre = addString("Introduce nombre: ");
    
    //creamos archivo
    Filecreator.createFile(tmpF + fileName, creaHtml(titulo,nombre));
    }
    
    public static String addString(String texto){
        //mostramos texto
        System.out.println(texto);
        //devolvemos resultado
        return new Scanner(System.in).next();
    }
    public static String creaHtml(String titulo,String nombre){
        ///Objeto Stringbuffer
        StringBuffer sb = new StringBuffer();
        /// Creando Html
        sb.append("<html>");
        sb.append("<head>" );
       sb.append("<title>" + titulo + "</title" );
         sb.append("/<head>");
          sb.append("<body>");
           sb.append("<h1>" + "Hola " + nombre + " </h1>");
           sb.append("</body>");                
         sb.append("</html>");
         /// Retornar el string con el titulo y el nombre
        return  sb.toString();
        
        
    }
}
